# Aksjeanalyse Pro V6.0 – Multi-børs

Nytt:
- Markedsvalg: Oslo, Stockholm, København, Helsinki og USA.
- Kuraterte screeninglister per marked.
- Samme analyse, score, kurs, 30/90 dager, 1 år, utbytte og innsidefelt.
- «Slik beregnes scoren» er lagt inn som info direkte i appen.
- PC-tabellen er gjort høyere/dynamisk slik at horisontal rulling blir enklere å nå.
- Resultater huskes bare for markedet de ble analysert på, slik at markedsbytte ikke blander data.
- © GS, Skjetten 2026 beholdt.

Merk: Listene utenfor Oslo er kuraterte store/likvide aksjer, ikke en garantert live Top 50-rangering.
Samme scoremodell på tvers av sektorer/markeder har begrensninger.

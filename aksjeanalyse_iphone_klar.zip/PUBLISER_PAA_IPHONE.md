# Publiser Aksjeanalyse på iPhone

Denne mappen er klar for Streamlit Community Cloud.

## 1. Legg filene på GitHub

Opprett et nytt GitHub-repository, for eksempel `aksjeanalyse`.

Last opp hele innholdet i denne mappen slik at repositoryet har:

- app.py
- requirements.txt
- README.md
- .streamlit/config.toml

Viktig: `.streamlit` er en mappe, og `config.toml` skal ligge inni den.

## 2. Publiser med Streamlit Community Cloud

1. Gå til https://share.streamlit.io/
2. Logg inn med GitHub.
3. Velg **Create app**.
4. Velg repositoryet `aksjeanalyse`.
5. Branch: vanligvis `main`.
6. Main file path / entrypoint: `app.py`.
7. Velg en ønsket app-adresse hvis feltet vises.
8. Trykk **Deploy**.

Når appen er publisert får du en adresse som slutter på `.streamlit.app`.

## 3. Bruk den på iPhone

Åpne app-adressen i Safari.

For å få et ikon på Hjem-skjermen:
1. Trykk Del-knappen i Safari.
2. Velg **Legg til på Hjem-skjermen**.
3. Gi den for eksempel navnet `Aksjeanalyse`.
4. Trykk **Legg til**.

## 4. Oppdatere appen senere

Endre `app.py` i GitHub og lagre/commit endringen. Streamlit Community Cloud henter normalt endringen automatisk.

## Norske tickere

Eksempler:
- EQNR.OL
- DNB.OL
- KOG.OL
- NHY.OL

## Viktig

Appen er et analyseverktøy basert på historiske markedsdata og en enkel poengmodell. Den er ikke et kjøps- eller salgsråd.

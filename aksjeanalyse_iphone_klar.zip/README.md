# Aksjeanalyse-app

## Kjør lokalt

1. Installer Python 3.
2. Åpne Terminal/PowerShell i denne mappen.
3. Installer pakkene:

   pip install -r requirements.txt

4. Start appen:

   streamlit run app.py

Hvis kommandoen `streamlit` ikke virker, bruk:

   python -m streamlit run app.py

Appen åpnes vanligvis automatisk i nettleseren.

## Norske aksjer

Bruk `.OL` etter tickeren, for eksempel:

- EQNR.OL
- DNB.OL
- KOG.OL
- NHY.OL

## Viktig

Dette er et analyseverktøy og ikke investeringsråd. Modellen bruker historiske data og en enkel poengscore.

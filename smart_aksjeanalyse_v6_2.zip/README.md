# Smart Aksjeanalyse V6.2

Nytt:
- Versjonsnummer vises permanent nederst på siden.
- Footer: © GS, Skjetten 2026 · Smart Aksjeanalyse V6.2
- Alle funksjoner fra V6.1 er beholdt.

Fremtidige versjoner bør alltid oppdatere versjonsnummeret i footeren.

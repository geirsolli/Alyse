# Aksjeanalyse Pro V5.10
Kritisk rettelse: V5.9 beregnet innsideverdier, men returnerte dem ikke til tabellen. Dette er rettet.
Innside-score, Innside 90d og kilde vises nå tidlig i Top 50-tabellen.
Manglende sikre data gir ingen straff i totalscoren.
Euronext/Oslo Børs er kontrollkilde for norske primærinnsidemeldinger.
© GS, Skjetten 2026 beholdt.
